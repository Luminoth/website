/*
====================
File: EnUtilities.h
Author: Shane Lillie
Description: General utilties module header.

(c) 2002-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#if !defined __ENUTILITIES_H__
#define __ENUTILITIES_H__

#if _MSC_VER >= 1000
#pragma once
#endif


/*
 *  extension unification
 *
 */


#if defined WIN32
    #define stdext std
#else
    #define stdext __gnu_cxx
    #define __declspec(t) 
#endif


/*
 *  pragmas
 *
 */


#if defined WIN32
    #pragma warning(disable : 4290) // really stupid exception deal
#endif


/*
 *  function redefinitions
 *
 */


#if defined WIN32
    #define snprintf _snprintf
    #define vsnprintf _vsnprintf
    #define strcasecmp _stricmp
    #define getcwd _getcwd
    #define sleep(s) Sleep(s * 1000)
    #define strtok_r(s, d, b) strtok((s), (d))
#endif


/*
 *  typedefs
 *
 */


#if defined WIN32
    typedef __int64 LongLong;
    typedef unsigned __int64 ULongLong;
#else
    typedef int HANDLE;
    typedef void* HINSTANCE;
    typedef HINSTANCE HMODULE;

    typedef long long LongLong;
    typedef unsigned long long ULongLong;
#endif

typedef unsigned char byte;     // 8-bit
typedef unsigned short word;    // 16-bit
typedef unsigned int dword;     // 32-bit
typedef ULongLong qword;        // 64-bit


/*
 *  macros
 *
 *  NOTE: these should be in EnFunctions.h,
 *  but have a more utilitarian purpose
 *
 */


#if !defined WIN32
    // from winsock2.h
    #define MAKEWORD(low, high) ((word)(((byte)(low)) | ((word)((byte)(high))) << 8))
#endif


/*
 *  constants
 *
 */


#if defined WIN32
    #define PATH_SEPARATOR ";"
    #define DIR_SEPARATOR "\\"
    #define EOL "\r\n"

    // how stupid is this shit?
    #define POINT_IN 72     // 1 point = 1/72 inch
    #define TWIP_PT 20      // 1 twip = 1/20 point
    #define TWIP_IN 1440    // 1 twip = 1/1440 inch
    #define TWIP_CM 567     // 1 twip = 1/567 cm
#else
    #define PATH_SEPARATOR ":"
    #define DIR_SEPARATOR "/"
    #define EOL "\n"

    // this is from windef.h
    // though it seems kinda small
    #define MAX_PATH 260
#endif


/*
struct EnPoint
*/
struct EnPoint
{
    unsigned int x, y, z;

    explicit EnPoint(unsigned int ax=0, unsigned int ay=0, unsigned int az=0)
        : x(ax), y(ay), z(az)
    {
    }
};


/*
struct EnRect
*/
struct EnRect
{
    EnPoint point;
    unsigned int w, h, d;

    explicit EnRect(const EnPoint& p, unsigned int aw=0, unsigned int ah=0, unsigned int ad=0)
        : point(p), w(aw), h(ah), d(ad)
    {
    }
};


/*
struct EnColor
*/
struct EnColor
{
    unsigned char r, g, b, a;

    explicit EnColor(unsigned char ar=0, unsigned char ag=0, unsigned char ab=0, unsigned char aa=0)
        : r(ar), g(ag), b(ab), a(aa)
    {
    }
};


#endif
