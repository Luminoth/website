/*
====================
File: EnFunctions.h
Author: Shane Lillie
Description: Utility function module header.

(c) 2002-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/


#if !defined __ENFUNCTIONS_H__
#define __ENFUNCTIONS_H__

#if _MSC_VER >= 1000
#pragma once
#endif

#if defined WIN32
    #define _USE_MATH_DEFINES
#endif

#include <cctype>
#include <cstring>
#include <cmath>
#include <string>


/*
 *  macros
 *
 */


// sets bit i of b
#define SET_BIT(b, i) ((b) |= (0x01 << (i)))

// determines if bit i of b is set
#define GET_BIT(b, i) (((b) >> (i)) & 0x01)

// determine if a number is odd
#define IS_ODD(n) ((n) & 0x01)

// determine if a number is even
#define IS_EVEN(n) (!IS_ODD((n)))

// converts between radians and degrees
// these could be faster by pre-computing
#define RAD_DEG(r) ((r) * 57.2957795)   // 180.0 / M_PI is about 57.2957795
#define DEG_RAD(d) ((d) * 0.0174532925) // M_PI / 180.0 is about 0.0174532925

// min/max
#if !defined MIN
    #define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#if !defined MAX
    #define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif


#if defined WIN32
    #define SAFE_RELEASE(p) { if((p)) { (p)->Release(); (p) = NULL; } }
#else
    #define ZeroMemory(d, l) std::memset((d), 0, (l))
#endif


/*
namespace EnergonSoftware
*/
namespace EnergonSoftware
{
    /*
     *  prototypes
     *
     */


    // calculates the crc32 value for the given data
    unsigned long crc32(const void* const data, size_t len);

    // skips whitespace on a file stream
    void skip_whitespace(std::ifstream& infile);

    // skips whitespace on a file
    void skip_whitespace(FILE* file);

    // creates a directory path
    // check errno on failure
    // NOTE: this doesn't error on EEXIST
    // although this may mean a file or
    // symbolic link was in the way
    bool create_path(const std::string& path, unsigned int mode);

    // trims whitespace from the front of a string
    // returns the trimmed string
    std::string trim_front_whitespace(const std::string& str);

    // trims whitespace from the back of a string
    // returns the trimmed string
    std::string trim_back_whitespace(const std::string& str);

    // trims whitespace from the front and back of a string
    // returns the trimmed string
    std::string trim_ends_whitespace(const std::string& str);

    // trims all whitespace from a string
    // including internal whitespace
    // returns the trimmed string
    std::string trim_all_whitespace(const std::string& str);

    // makes a string all lowercase
    // returns the lowered string
    std::string tolower_str(const std::string& str);

    // makes a C-string all lowercase
    // puts the new string in dest
    // NOTE: this assumes dest has enough room
    // to hold the length of str
    void tolower_str(char* dest, const char* src);

    // duplicates a C-string using C-style
    // malloc() call (for functions that end
    // up calling free() on the buffer)
    char* dup_cstr(const char* str, size_t len);

    // converts an integer to a string
    std::string itoa(int i);

    // returns the next largest power of 2
    unsigned long power_of_two(float x);

    // converts a binary number in a string to a long long value
    LongLong binary_strtoll(const std::string& number);

    // returns true if the given file exists
    // set writeable to true to test for writeability
    bool file_exists(const std::string& filename, bool writeable=false);

    // returns the path to a given file
    // returns an empty string if the file doesn't exist
    // uses the PATH environment variable
    std::string find_file_in_path(const std::string& filename);

    // returns the error created by using strerror() and errno.
    std::string last_std_error();
    std::string last_std_error(int error);

    // in Windows, returns the error created
    // by using FormatMessage() and GetLastError()
    // everywhere else, returns last_std_error()
    std::string last_error();
    std::string last_error(int error);

    // gets the program directory
    // how_ran should be argv[0]
    // returns the directory
    // NOTE: this is pretty bad, it combines the current working directory
    // with how_ran to get the program's directory
    // NOTE: this doesn't work correctly in Windows
    std::string application_directory(std::string how_ran);


    /*
     *  functions
     *
     */


    // strips the path from a filename
    // returns the stripped filename
    inline std::string strip_path(const std::string& filename)
    {
        size_t pos = filename.rfind("/");
        return (pos != std::string::npos ? filename.substr(pos+1) : filename);
    }

    // gets the path from a filename
    // returns the stripped path
    inline std::string get_path(const std::string& filename)
    {
        size_t pos = filename.rfind("/");
        return (pos != std::string::npos ? filename.substr(0, pos+1) : filename);
    }

    // converts a hex character to its equivalent integer value byte
    // NOTE: this only works for single-byte ASCII characters
    inline byte hex_to_byte(unsigned char hex)
    {
        return isalpha(hex) ? (isupper(hex) ? hex - '7' : hex - 'W') : hex - '0';
    }

    // combines two nibbles into one word
    inline byte make_byte(byte msb, byte lsb)
    {
        return (msb << 4) | lsb;
    }

    // combines two bytes into one word
    // NOTE: this isn't portable
    inline word make_word(byte msb, byte lsb)
    {
        word ret(0);
        return (((ret | msb) << 8) | lsb);
    }


    /*
     *  Specialized prototypes
     *
     */


#if !defined WIN32
    // gets the uid associated with a user
    // sets error to true on error and returns 0
    uid_t user_id(const std::string& username, bool& error);

    // gets the gid associated with a group
    // sets error to true on error and returns 0
    gid_t group_id(const std::string& groupname, bool& error);
#endif
}


#endif
