/*
====================
File: EnConfig.h
Author: Shane Lillie
Description: Configuration file module header.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#if !defined __ENCONFIG_H__
#define __ENCONFIG_H__

#if _MSC_VER >= 1000
#pragma once
#endif


#include <stdexcept>
#include <string>
#include <map>
#include <iosfwd>


struct EnConfigOption;


/*
 *  typedefs
 *
 */


typedef std::map<std::string, std::string> EnConfigOptions;


/*
class EnConfig

Used to load/store/save application
configuration options.
*/
class EnConfig
{
public:
    class EnConfigException : public std::exception
    {
    public:
        EnConfigException(const std::string& what) throw() : _what(what) { }
        virtual ~EnConfigException() throw() { }
        virtual const char* what() const throw() { return _what.c_str(); }
    private:
        std::string _what;
    };

public:
    EnConfig();
    explicit EnConfig(const std::string& filename);

public:
    // sets a default option value
    void set_default(const std::string& option, const std::string& value=std::string());

    // sets all default values
    // from an array of EnConfigOption vars
    // NOTE: the last option MUST have an empty name
    void set_defaults(const EnConfigOption* options);

    // loads the default options
    // into the current set
    void load_defaults();

    // sets a config value
    void set(const std::string& option, const std::string& value=std::string());

    // looks up a config value
    // returns an empty string
    // if the value doesn't exist
    std::string get(const std::string& option) const;

    // looks up a config value
    // throws if the value doesn't exist
    const std::string& lookup(const std::string& option) const throw(EnConfigException);

    // reads a config from a file
    // use filename(std::string&) to set
    // the file to read from
    // if the file can't be opened, save()
    // is called (which may fail)
    bool load();

    // reads a config from a file
    // if the file can't be opened, save()
    // is called (which may fail)
    bool load(const std::string& filename);

    // writes the config to a file
    // use filename(std::string&) to set
    // the file to write to
    bool save();

    // writes the config to a file
    // internally calls filename(std::string&)
    // to update the current filename
    bool save(const std::string& filename);

    // returns true if the config file exits
    bool exists() const;

    // dumps the config to an output stream
    void dump(std::ostream& out) const;

public:
    const std::string& filename() const
    {
        return m_filename;
    }

    void filename(const std::string& name)
    {
        m_filename = name;
    }

    void set_header(const std::string& header)
    {
        m_header = header;
    }

    bool changed() const
    {
        return m_changed;
    }

    void changed(bool changed)
    {
        m_changed = changed;
    }

private:
    EnConfig(const EnConfig& config);
    EnConfig& operator=(const EnConfig& rhs);

private:
    std::string m_header, m_filename;
    EnConfigOptions m_options;
    EnConfigOptions m_defaults;
    bool m_changed;
};


/*
struct EnConfigOption

This is useful for storing
default config options and
for keeping track of what
options are available
*/
struct EnConfigOption
{
    std::string name;
    const std::string default_value;

    EnConfigOption(const std::string& n=std::string(), const std::string& dv=std::string())
        : name(n), default_value(dv)
    {
    }
};


#endif
