/*
====================
File: EnLog.h
Author: Shane Lillie
Description: Log file module header.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#if !defined __ENLOG_H__
#define __ENLOG_H__

#if _MSC_VER >= 1000
#pragma once
#endif


#include <string>
#include <ostream>
#include <iosfwd>


/*
 *  typedefs
 *
 */


typedef void (*OnLogFunction)(const std::string&);


/*
 *  constants
 *
 */


enum LogOutputType
{
    LogOutputNormal,
    LogOutputWarning,
    LogOutputError,
    LogOutputDebug,
    LogOutputTodo
};


/*
class EnLog

Used to log messages to a file stream.
Defaults to using stdout.
*/
class EnLog
{
public:
    enum
    {
        MAX_MESSAGE = 2048
    };

public:
    EnLog();
    ~EnLog();

public:
    // redirects the log to a file
    // overwrites the file unless append is true
    // returns false if the redirection failed
    bool redirect(const std::string& filename, bool append=true);

    // restores the log to stdout
    void restore();

    // logs a message to the log
    void log(const std::string& msg, LogOutputType type=LogOutputNormal);

    // logs a message to the log
    // followed by a new line
    void logln(const std::string& msg=std::string(), LogOutputType type=LogOutputNormal);

    // logs a formatted message to the log
    void vlog(LogOutputType type, const char* fmt, ...);

    // logs a formatted message to the log
    // followed by a new line
    void vlogln(LogOutputType type, const char* fmt, ...);

    // sets the function to call when
    // something is logged (for game
    // consoles, dual logging, etc.)
    void set_on_log(OnLogFunction function=NULL);

    // flushes the log
    void flush();

public:
    // returns true if the log is redirected
    bool redirected() const
    {
        return m_file != NULL;
    }

    // returns the re-directed filename
    const std::string& filename() const
    {
        return m_filename;
    }

private:
    void do_log(const std::string& msg);
    EnLog(const EnLog& log);
    EnLog& operator=(const EnLog& rhs);

private:
    std::ofstream* m_file;
    std::string m_filename;
    OnLogFunction m_on_log;
};


#endif
