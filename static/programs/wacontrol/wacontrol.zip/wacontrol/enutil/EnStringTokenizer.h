/*
====================
File: EnStringTokenizer.h
Author: Shane Lillie
Description: String tokenizer module header.

(c) 2001-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#if !defined __ENSTRINGTOKENIZER_H__
#define __ENSTRINGTOKENIZER_H__

#if _MSC_VER >= 1000
#pragma once
#endif


#include <stdexcept>
#include <string>
#include <vector>


/*
class EnStringTokenizer
*/
class EnStringTokenizer
{
private:
    // defaults to " \n\t\f\r"
    static const std::string DEF_DELIMS;

public:
    explicit EnStringTokenizer(const std::string& str, const std::string& delims=DEF_DELIMS);

public:
    // returns the next token in the string
    // throws if no more tokens
    const std::string& next() throw(std::out_of_range);

public:
    // returns the number of tokens
    // in the string
    size_t count_tokens() const
    {
        return m_tokens.size();
    }

    // returns true if there are
    // more tokens to look at
    bool has_more_tokens() const
    {
        return m_current < count_tokens();
    }

    // resets the current token
    // to the first one
    void reset()
    {
        m_current = 0;
    }

private:
    std::string m_string, m_delims;
    std::vector<std::string> m_tokens;
    unsigned int m_current;

private:
    void tokenize();

private:
    EnStringTokenizer();
    EnStringTokenizer(const EnStringTokenizer& st);
    EnStringTokenizer& operator=(const EnStringTokenizer& rhs);
};


#endif
