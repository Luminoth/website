/*
====================
File: EnStringTokenizer.cc
Author: Shane Lillie
Description: String tokenizer module source.

(c) 2001-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#include "pch.h"

#include <cstring>

#include "EnStringTokenizer.h"


/*
 *  EnStringTokenizer class constants
 *
 */


const std::string EnStringTokenizer::DEF_DELIMS = " \n\t\f\r";


/*
 *  EnStringTokenizer methods
 *
 */


EnStringTokenizer::EnStringTokenizer(const std::string& str, const std::string& delims)
    : m_string(str), m_delims(delims), m_current(0)
{
    tokenize();
}


const std::string& EnStringTokenizer::next() throw(std::out_of_range)
{
    if(!has_more_tokens())
        throw std::out_of_range("No tokens left!");
    return m_tokens[m_current++];
}


void EnStringTokenizer::tokenize()
{
    const size_t len = m_string.length();

    // copy the string for tokenizing
    char* scratch = new char[len + 1];
    std::strcpy(scratch, m_string.c_str());
    scratch[len] = '\0';

    char* buffer = new char[len + 1];
    char* token = strtok_r(scratch, m_delims.c_str(), &buffer);
    while(token) {
        m_tokens.push_back(token);
        token = strtok_r(NULL, m_delims.c_str(), &buffer);
    }
    delete[] buffer;
    delete[] scratch;
}
