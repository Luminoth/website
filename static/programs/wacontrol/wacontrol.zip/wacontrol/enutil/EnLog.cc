/*
====================
File: EnLog.cc
Author: Shane Lillie
Description: Log file module source.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#include "pch.h"

#include <ctime>
#include <cstdarg>
#include <iostream>
#include <fstream>

#include "EnLog.h"


/*
 *  EnLog methods
 *
 */


EnLog::EnLog()
    : m_file(NULL), m_on_log(NULL)
{
}


EnLog::~EnLog()
{
    restore();
}


bool EnLog::redirect(const std::string& filename, bool append)
{
    restore();

    m_file = new std::ofstream(filename.c_str(), append ? std::ios::app : std::ios::trunc);
    if(!m_file || !m_file->is_open()) {
        restore();
        return false;
    }
    m_file->close();
    m_filename = filename;

    logln("Log redirected to " + m_filename);
    return true;
}


void EnLog::restore()
{
    if(m_file) {
        logln("Restoring log to stdout");
        delete m_file;
        m_file = NULL;
    }
}


void EnLog::log(const std::string& msg, LogOutputType type)
{
    if(m_file) m_file->open(m_filename.c_str(), std::ios::app);

    switch(type)
    {
    case LogOutputNormal:
        do_log(msg);
        break;
    case LogOutputWarning:
        do_log("WARNING: " + msg);
        break;
    case LogOutputError:
        do_log("ERROR: " + msg);
        break;
    case LogOutputDebug:
#if !defined NDEBUG
        do_log("DEBUG: " + msg);
#endif
        break;
    case LogOutputTodo:
#if !defined NDEBUG
        do_log("TODO: " + msg);
#endif
        break;
    }

    if(m_file) {
        m_file->flush();
        m_file->close();
    }
}


void EnLog::logln(const std::string& msg, LogOutputType type)
{
    log(msg + EOL, type);
}


void EnLog::vlog(LogOutputType type, const char* fmt, ...)
{
    char buffer[MAX_MESSAGE];

    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buffer, MAX_MESSAGE, fmt, ap);
    va_end(ap);

    log(buffer, type);
}


void EnLog::vlogln(LogOutputType type, const char* fmt, ...)
{
    char buffer[MAX_MESSAGE];

    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buffer, MAX_MESSAGE, fmt, ap);
    va_end(ap);

    logln(buffer, type);
}


void EnLog::set_on_log(OnLogFunction function)
{
    m_on_log = function;
}


void EnLog::flush()
{
    if(m_file) m_file->flush();
    else std::cout.flush();
}


void EnLog::do_log(const std::string& msg)
{
    if(m_file && m_file->is_open()) {
        // get the local time
        time_t tm = std::time(NULL);
        struct tm* stamp = std::localtime(&tm);

        // time stamp the log
        char buffer[64];
        std::strftime(buffer, 64, "%c", stamp);

        (*m_file) << buffer << " - " << msg;
    } else
        std::cout << msg;

    if(m_on_log) m_on_log(msg);
}
