/*
====================
File: EnConfig.cc
Author: Shane Lillie
Description: Configuration file module source.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#include "pch.h"

#include <cstring>
#include <iostream>
#include <fstream>

#include "EnConfig.h"
#include "EnFunctions.h"


using namespace EnergonSoftware;


/*
 *  EnConfig methods
 *
 */


EnConfig::EnConfig()
    : m_changed(false)
{
}


EnConfig::EnConfig(const std::string& filename)
    : m_filename(filename), m_changed(false)
{
}


void EnConfig::set_default(const std::string& option, const std::string& value)
{
    m_defaults[option] = value;
}


void EnConfig::set_defaults(const EnConfigOption* options)
{
    assert(options);
    if(!options) return;

    while(!options->name.empty()) {
        set_default(options->name, options->default_value);
        options++;
    }
}


void EnConfig::load_defaults()
{
    m_options = m_defaults;
    m_changed = true;
}


void EnConfig::set(const std::string& option, const std::string& value)
{
    m_options[option] = value;
    m_changed = true;
}


std::string EnConfig::get(const std::string& option) const
{
    EnConfigOptions::const_iterator it = m_options.find(option);
    if(it != m_options.end())
        return it->second;
    return std::string();
}


const std::string& EnConfig::lookup(const std::string& option) const throw(EnConfigException)
{
    EnConfigOptions::const_iterator it = m_options.find(option);
    if(it != m_options.end())
        return it->second;
    throw EnConfigException("Config option does not exist: " + option);
}


bool EnConfig::load()
{
    std::ifstream infile(m_filename.c_str());
    if(!infile) return save();

    std::string scratch;
    while(!infile.eof()) {
        std::getline(infile, scratch);
        if(scratch.empty())
            continue;

        // strip comments
        size_t pos = scratch.find('#');
        if(pos != std::string::npos)
            scratch.erase(pos);

        // strip the ends whitespace
        // this is more to get rid of
        // lazy space after comment removal
        scratch = trim_ends_whitespace(scratch);
        if(scratch.empty())
            continue;

        pos = scratch.find('=');
        if(pos == std::string::npos)
            return false;

        // trim all whitespace from the option
        // trim ends whitespace from the value
        set(trim_all_whitespace(scratch.substr(0, pos)), trim_ends_whitespace(scratch.substr(pos + 1)));
    }
    return true;
}


bool EnConfig::load(const std::string& filename)
{
    this->filename(filename);
    return load();
}


bool EnConfig::save()
{
    std::ofstream outfile(m_filename.c_str());
    if(!outfile) return false;

    outfile << m_header;

    for(EnConfigOptions::const_iterator it = m_options.begin(); it != m_options.end(); ++it)
        outfile << trim_all_whitespace(it->first) << " = " << trim_ends_whitespace(it->second) << std::endl;
    m_changed = false;
    return true;
}


bool EnConfig::save(const std::string& filename)
{
    this->filename(filename);
    return save();
}


bool EnConfig::exists() const
{
    if(m_filename.empty())
        return false;

    std::ifstream infile(m_filename.c_str());
    return infile.is_open();
}


void EnConfig::dump(std::ostream& out) const
{
    out << m_header;
    for(EnConfigOptions::const_iterator it = m_options.begin(); it != m_options.end(); ++it)
        out << trim_all_whitespace(it->first) << " = " << trim_ends_whitespace(it->second) << std::endl;
    out << std::endl;
}
