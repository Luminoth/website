//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by wacontrold.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDS_ERR_LOAD_CONFIG             129
#define IDS_ERR_CREATE_WINDOW           130
#define IDS_ERR_SAVE_CONFIG             131
#define IDS_ERR_PACKET                  132
#define IDS_ERR_LOG_REDIRECT            133
#define IDS_ERR_SENDPACKET              134
#define IDS_ERR_WINSOCK                 135
#define IDS_ERR_SELECT                  136
#define IDS_ERR_CONNECT                 137
#define IDS_ERR_RECVPACKET              138
#define IDR_TRAY_MENU                   201
#define IDC_CLIENTS_STATIC              1000
#define ID_FILE_DETAILS                 32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
