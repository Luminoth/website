/*
====================
File: EnSocket.h
Author: Shane Lillie
Description: Socket module header.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#if !defined __ENSOCKET_H__
#define __ENSOCKET_H__

#if _MSC_VER >= 1000
#pragma once
#endif


#include <string>

#if !defined WIN32
    #include <unistd.h>

    #include <sys/types.h>
    #include <sys/socket.h>

    #include <netinet/in.h>
#endif


class EnServerSocket;
class EnClientSocket;
class EnPacket;
struct hostent;


/*
class EnSocket

Base socket class.
*/
class EnSocket
{
public:
    // returns the last error value
    static int last_socket_error();

    // converts the given hostname/ip address to an in_addr/in6_addr
    // size is the size of the in_addr/in6_addr structure
    // NOTE: this only deals with the first address resolved
    // NOTE: this uses inet_addr()/gethostbyname() if
    // inet_pton()/gethostbyname2() are not supported,
    // thus ignoring IPv6 support (and the domain parameter)
    static bool host_to_inaddr(int domain, const std::string& host, void* iaddr, size_t size);

public:
    EnSocket();
    explicit EnSocket(SOCKET sockfd);

public:
    bool create(int domain, int type, int protocol=IPPROTO_TCP);
    bool shutdown(int how=SHUT_RDWR);
    bool close();

    // these compensate for incomplete sends
    bool send(const EnPacket& packet, int flags=0);
    bool send(const char* buffer, size_t len, int flags=0);

    // these require calling create_addr()
    // and do compensate for incomplete sends
    bool sendto(const EnPacket& packet, int flags=0);
    bool sendto(const char* buffer, size_t len, int flags=0);

    // these return the value of ::recv()
    int recv(EnPacket& packet, int flags=0);
    int recv(char* buffer, size_t len, int flags=0);

    // these require calling create_addr()
    int recvfrom(EnPacket& packet, int flags=0);
    int recvfrom(char* buffer, size_t len, int flags=0);

#if defined WIN32
    bool setsockopt(int optname, const char* optval, socklen_t optlen, int level=SOL_SOCKET);
    bool getsockopt(int optname, char* optval, socklen_t* optlen, int level=SOL_SOCKET);
#else
    bool setsockopt(int optname, const void* optval, socklen_t optlen, int level=SOL_SOCKET);
    bool getsockopt(int optname, void* optval, socklen_t* optlen, int level=SOL_SOCKET);
#endif

    bool set_asynchronous();
    bool get_asynchronous();

    bool set_synchronous();
    bool get_synchronous();

#if defined WIN32
    // calls WSAAsyncSelect()
    bool async_select(HWND hWnd, UINT uMsg, long lEvent);

    // calls WSAEventSelect
    bool event_select(WSAEVENT hEventObject, long lNetworkEvents);
#endif

public:
    SOCKET socket() const
    {
        return m_sockfd;
    }

    bool valid() const
    {
        return m_sockfd != INVALID_SOCKET;
    }

protected:
    SOCKET m_sockfd;
    int m_domain;
    sockaddr_in m_addr;
};


/*
class EnServerSocket

A server socket.
*/
class EnServerSocket : public EnSocket
{
public:
    // creates a simple server socket
    // sets the socket to reuse addresses
    // and calls bind() and listen() on it
    static bool create_server_socket(EnServerSocket& socket, int domain, int type, unsigned short port);

public:
    EnServerSocket();
    explicit EnServerSocket(SOCKET sockfd);

public:
    // these are for datagram sockets
    void create_addr(unsigned short port);
    bool create_addr(const std::string& address, unsigned short port);

    // calls ::bind()
    bool bind(unsigned short port);
    bool bind(const std::string& address, unsigned short port);

    // calls ::listen()
    bool listen(int backlog=SOMAXCONN);

    // calls ::accept()
    EnClientSocket accept();
};


/*
class EnClientSocket

A client socket.
*/
class EnClientSocket : public EnSocket
{
public:
    // creates a simple client socket
    // and connects it to the given host
    static bool create_client_socket(EnClientSocket& socket, int domain, int type, const std::string& host, unsigned short port);

public:
    EnClientSocket();
    explicit EnClientSocket(SOCKET sockfd);

public:
    // these is for datagram sockets
    bool create_addr(const std::string& host, unsigned short port);

    // calls ::connect()
    bool connect(const std::string& host, unsigned short port);
};


#endif
