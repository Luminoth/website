/*
====================
File: EnPacket.cc
Author: Shane Lillie
Description: EnPacket module header.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#include "pch.h"

#include <cctype>
#include <cstring>
#include <iostream>

#if !defined WIN32
    #include <netinet/in.h>
#endif

#include "EnPacket.h"
#include "EnLog.h"
#include "EnFunctions.h"


/*
 *  constants
 *
 */


const byte MSG_STRING = 0x01;
const byte MSG_BYTE   = 0x02;
const byte MSG_WORD   = 0x03;
const byte MSG_DWORD  = 0x04;
const byte MSG_QWORD  = 0x05;
const byte MSG_SIZET  = 0x06;


/*
 *  EnPacket methods
 *
 */


EnPacket::EnPacket()
    : m_index(0), m_length(0)/*,
        m_compression(0), m_uncompressed_len(0)*/
{
    //ZeroMemory(m_buffer, MaxPacket);
}


EnPacket::EnPacket(const EnPacket& packet)
    : m_index(packet.m_index), m_length(packet.m_length)/*,
        m_compression(packet.m_compression), m_uncompressed_len(packet.m_uncompressed_len)*/
{
    //ZeroMemory(m_buffer, MaxPacket);
    std::memcpy(m_buffer, packet.m_buffer, MaxPacket);
}


void EnPacket::erase()
{
    m_index = 0;
    m_length = 0;

    //ZeroMemory(m_buffer, MaxPacket);

    /*m_compression = 0;
    m_uncompressed_len = 0;*/
}


void EnPacket::pack_string(const std::string& value)
{
    const size_t len = value.length();

    // pack the string header,
    // the length of the string,
    // then the string itself
    push_back(MSG_STRING);
    pack_sizet(len);
    push_back(value.c_str(), len);
}


bool EnPacket::unpack_string(std::string& value)
{
    // gotta have a string header
    if(m_buffer[m_index] != MSG_STRING)
        return false;
    m_index++;

    // unpack the string length
    size_t len;
    if(!unpack_sizet(len))
        return false;

    // copy the string
    value.erase();
    for(size_t i=0; i<len; ++i)
        value += m_buffer[m_index++];
    return true;
}


void EnPacket::pack_byte(byte value)
{
    // pack the byte header,
    // then the byte itself
    push_back(MSG_BYTE);
    push_back(&value, 1);
}


bool EnPacket::unpack_byte(byte& value)
{
    // gotta have a byte header
    if(m_buffer[m_index] != MSG_BYTE)
        return false;
    m_index++;

    // copy the byte
    value = m_buffer[m_index++];
    return true;
}


void EnPacket::pack_word(word value)
{
    const size_t size = sizeof(word);
    const size_t bits = (size << 3) - 8;    // minus 8 to make the loop equation work good
    byte buf[size] = { 0 };

    // convert to network byte order
    word nval = htons(value);

    // copy the value
    word temp(0);
    for(size_t i=0; i<size; ++i) {
        temp = static_cast<word>(nval >> (bits - (i << 3)));
        buf[i] = temp & 0x00ff;
    }

    // pack the word header,
    // then the word itself
    push_back(MSG_WORD);
    push_back(buf, size);
}


bool EnPacket::unpack_word(word& value)
{
    // gotta have a word header
    if(m_buffer[m_index] != MSG_WORD)
        return false;
    m_index++;

    const size_t size = sizeof(word);

    // copy the value
    word temp(0);
    for(size_t i=0; i<size; ++i) {
        temp <<= 8;
        temp |= m_buffer[m_index++] & 0x00ff;
    }

    // convert to host byte order
    value = ntohs(temp);
    return true;
}


void EnPacket::pack_dword(dword value)
{
    const size_t size = sizeof(dword);
    const size_t bits = (size << 3) - 8;    // minus 8 to make the loop equation work good
    byte buf[size] = { 0 };

    // convert to network byte order
    dword nval = htonl(value);

    // copy the value
    dword temp(0);
    for(size_t i=0; i<size; ++i) {
        temp = nval >> (bits - (i << 3));
        buf[i] = temp & 0x000000ff;
    }

    // pack the dword header,
    // then the dword itself
    push_back(MSG_DWORD);
    push_back(buf, size);
}


bool EnPacket::unpack_dword(dword& value)
{
    // gotta have a dword header
    if(m_buffer[m_index] != MSG_DWORD)
        return false;
    m_index++;

    const size_t size = sizeof(dword);

    // copy the value
    dword temp(0);
    for(size_t i=0; i<size; ++i) {
        temp <<= 8;
        temp |= m_buffer[m_index++] & 0x000000ff;
    }

    // convert to host byte order
    value = ntohl(temp);
    return true;
}


void EnPacket::pack_sizet(size_t value)
{
    const size_t size = sizeof(size_t);
    const size_t bits = (size << 3) - 8;    // minus 8 to make the loop equation work good
    byte buf[size] = { 0 };

    // convert to network byte order
    size_t nval = htonl(static_cast<unsigned long>(value));

    // copy the value
    size_t temp;
    for(size_t i=0; i<size; ++i) {
        temp = nval >> (bits - (i << 3));
        buf[i] = static_cast<byte>(temp & 0x000000ff);
    }

    // pack the size_t header,
    // then the size_t itself
    push_back(MSG_SIZET);
    push_back(buf, size);
}


bool EnPacket::unpack_sizet(size_t& value)
{
    // gotta have a size_t header
    if(m_buffer[m_index] != MSG_SIZET)
        return false;
    m_index++;

    const size_t size = sizeof(size_t);

    // copy the value
    size_t temp = 0;
    for(size_t i=0; i<size; ++i) {
        temp <<= 8;
        temp |= m_buffer[m_index++] & 0xff;
    }

    // convert to host byte order
    value = ntohl(static_cast<unsigned long>(temp));
    return true;
}


#if 0
int EnPacket::compress(int level)
{
    int len = /*m_length*/m_buffer.length() + static_cast<int>(std::ceilf(static_cast<float>(/*m_length*/ m_buffer.length()) * 0.1f)) + 12;
    char* buffer = new char[len];

    int retval = 1; /*::compress(buffer, &len, m_buffer.c_str(), m_buffer.length());
    if(retval != Z_OK) {
        delete[] buffer;
        return retval;
    }

    m_uncompressed_len = m_buffer.length();
    m_buffer = buffer;*/
    delete[] buffer;

    m_compression = 0; //level;
    return retval;
}
#endif


const byte* const EnPacket::sendable_buffer() const
{
#if 0
    const size_t len = m_buffer.length() + 4;
    char* buffer = new char[len];

    buffer[0] = m_compression + 'a';        // compression level
    buffer[1] = m_uncompressed_len + 'a';   // uncompressed length
    buffer[2] = 'a';                        // encryption level

    std::memcpy(buffer + 2, m_buffer.c_str(), len);
    buffer[len - 1] = '\0';

    /* TODO: let's not have 3 copies... */
    std::string ret(buffer);
    delete[] buffer;
    return ret;
#endif

    return m_buffer;
}


void EnPacket::received_buffer(const byte* const buffer, size_t size)
{
/* TODO: deal with the header stuff */

    erase();
    push_back(buffer, size);
}


EnPacket& EnPacket::operator=(const EnPacket& rhs)
{
    if(this != &rhs) {
        m_index = rhs.m_index;
        m_length = rhs.m_length;
        /*m_compression = rhs.m_compression;
        m_uncompressed_len = packet.m_uncompressed_len;*/

        //ZeroMemory(m_buffer, MaxPacket);
        std::memcpy(m_buffer, rhs.m_buffer, MaxPacket);
    }
    return *this;
}


void EnPacket::push_back(byte value)
{
    // avoid overflow
    if(m_length >= MaxPacket)
        return;

    m_buffer[m_length] = value;
    m_length++;
}


void EnPacket::push_back(const void* buffer, size_t size)
{
    const byte* ptr = reinterpret_cast<const byte*>(buffer);
    const byte* const end = ptr + size;

    // copy in the new data
    // avoid overflow as well
    while(ptr < end && m_length < MaxPacket) {
        m_buffer[m_length] = *ptr;
        m_length++;
        ptr++;
    }
}


#if 0
int EnPacket::uncompress()
{
/* TODO: zlib uncompress() here */

return 0;
}
#endif


/*
 *  EnPacket friend functions
 *
 */


std::ostream& operator<<(std::ostream& lhs, const EnPacket& rhs)
{
    const byte* ptr = rhs.m_buffer;
    const byte* end = rhs.m_buffer + rhs.length();

    lhs.setf(std::ios::showbase);
    while(ptr < end) {
        if(isprint(*ptr))
            lhs << *ptr << " ";
        else
            lhs << std::hex << static_cast<int>(*ptr) << std::dec << " ";
        ptr++;
    }
    return lhs;
}


EnLog& operator<<(EnLog& lhs, const EnPacket& rhs)
{
    const byte* ptr = rhs.m_buffer;
    const byte* end = rhs.m_buffer + rhs.length();

    while(ptr < end) {
        if(isprint(*ptr))
            lhs.vlog(LogOutputNormal, "%c ", *ptr);
        else
            lhs.vlog(LogOutputNormal, "0x%x ", static_cast<int>(*ptr));
        ptr++;
    }
    return lhs;
}
