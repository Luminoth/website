/*
====================
File: EnPacket.h
Author: Shane Lillie
Description: EnPacket module header.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#if !defined __ENPACKET_H__
#define __ENPACKET_H__

#if _MSC_VER >= 1000
#pragma once
#endif


#include <string>
#include <iosfwd>


class EnLog;


/*
class EnPacket

NOTE: this takes care of
network byte ordering on
multi-byte packets except
where explicitly stated

NOTE: if the packet goes
over the max size, it's
truncated silently
*/
class EnPacket
{
public:
    enum
    {
        MaxPacket = 2048
    };

public:
    EnPacket();
    EnPacket(const EnPacket& packet);

public:
    // erases the packet buffer
    void erase();

public:
    // packs/unpacks a string
    void pack_string(const std::string& value);
    bool unpack_string(std::string& value);

    // packs/unpacks bytes
    void pack_byte(byte value);
    bool unpack_byte(byte& value);

    // packs/unpacks words
    void pack_word(word value);
    bool unpack_word(word& value);

    // packs/unpacks dwords
    void pack_dword(dword value);
    bool unpack_dword(dword& value);

    // packs/unpacks size_ts
    void pack_sizet(size_t value);
    bool unpack_sizet(size_t& value);

    // compresses the packet
    // refer to the zlib manual
    // for details on the level
    // parameter
    //int compress(int level);

    // returns a sendable buffer
    const byte* const sendable_buffer() const;

    // makes the current buffer
    // the one that was recieved
    void received_buffer(const byte* const buffer, size_t size);

public:
    EnPacket& operator=(const EnPacket& rhs);

public:
    // dumps the current buffer
    friend std::ostream& operator<<(std::ostream& lhs, const EnPacket& rhs);
    friend EnLog& operator<<(EnLog& lhs, const EnPacket& rhs);

public:
    size_t length() const
    {
        return m_length;
    }

    const byte* const buffer() const
    {
        return m_buffer;
    }

    /*int compression() const
    {
        return m_compression;
    }*/

    void reset()
    {
        m_index = 0;
    }

private:
    void push_back(byte value);
    void push_back(const void* const buffer, size_t size);
    //int uncompress();

private:
    unsigned int m_index;
    byte m_buffer[MaxPacket];
    size_t m_length;
    /*int m_compression;
    int m_uncompressed_len;*/
};


#endif
