/*
====================
File: EnSocketSet.cc
Author: Shane Lillie
Description: EnSocketSet module source.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#include "pch.h"

#include "EnFunctions.h"
#include "EnSocketSet.h"


/*
 *  EnSocketSet functions
 *
 */


int EnSocketSet::select(int maxsocket, EnSocketSet& read, EnSocketSet& write, EnSocketSet& except, timeval* timeout)
{
    return ::select(maxsocket, &read.m_fds, &write.m_fds, &except.m_fds, timeout);
}


/*
 *  EnSocketSet methods
 *
 */


EnSocketSet::EnSocketSet()
{
    FD_ZERO(&m_fds);
}


EnSocketSet::EnSocketSet(const EnSocketSet& set)
{
    std::memcpy(&m_fds, &set.m_fds, sizeof(fd_set));
}


void EnSocketSet::set(const EnSocket& socket)
{
    if(!socket.valid())
        return;

    FD_SET(socket.socket(), &m_fds);
}


void EnSocketSet::set(SOCKET socket)
{
    if(socket == INVALID_SOCKET)
        return;

    FD_SET(socket, &m_fds);
}


void EnSocketSet::clear(const EnSocket& socket)
{
    if(!socket.valid())
        return;

    FD_CLR(socket.socket(), &m_fds);
}


void EnSocketSet::clear(SOCKET socket)
{
    if(socket == INVALID_SOCKET)
        return;

    FD_CLR(socket, &m_fds);
}


bool EnSocketSet::is_set(const EnSocket& socket) const
{
    if(!socket.valid())
        return false;

    return static_cast<bool>(FD_ISSET(socket.socket(), &m_fds));
}


bool EnSocketSet::is_set(SOCKET socket) const
{
    if(socket == INVALID_SOCKET)
        return false;

    return static_cast<bool>(FD_ISSET(socket, &m_fds));
}


int EnSocketSet::select(int maxsocket, SelectType type, timeval* timeout)
{
    switch(type)
    {
    case SelectRead:
        return ::select(maxsocket, &m_fds, NULL, NULL, timeout);
    case SelectWrite:
        return ::select(maxsocket, NULL, &m_fds, NULL, timeout);
    case SelectExcept:
        return ::select(maxsocket, NULL, NULL, &m_fds, timeout);
    }

    // this shouldn't happen
    return -1;
}


int EnSocketSet::select(int maxsocket, EnSocketSet& except, SelectType type, timeval* timeout)
{
    switch(type)
    {
    case SelectRead:
        return ::select(maxsocket, &m_fds, NULL, &except.m_fds, timeout);
    case SelectWrite:
        return ::select(maxsocket, NULL, &m_fds, &except.m_fds, timeout);
    case SelectExcept:
        return ::select(maxsocket, NULL, NULL, &except.m_fds, timeout);
    }

    // this shouldn't happen
    return -1;
}


void EnSocketSet::erase()
{
    FD_ZERO(&m_fds);
}


EnSocketSet& EnSocketSet::operator=(const EnSocketSet& rhs)
{
    std::memcpy(&m_fds, &rhs.m_fds, sizeof(fd_set));
    return *this;
}
