/*
====================
File: EnSocket.cc
Author: Shane Lillie
Description: EnSocket module source.

(c) 2003-2004 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
====================
*/

#include "pch.h"

#include <cstring>
#include <cerrno>
#include <iostream>

#if !defined WIN32
    #include <unistd.h>
    #include <fcntl.h>

    #include <arpa/inet.h>
    #include <netdb.h>
#endif

#include "EnSocket.h"
#include "EnPacket.h"
#include "EnFunctions.h"


/*
 *  external globals
 *
 */


extern int errno;


/*
 *  EnSocket class functions
 *
 */


int EnSocket::last_socket_error()
{
#if defined WIN32
    return WSAGetLastError();
#else
    return errno;
#endif
}


bool EnSocket::host_to_inaddr(int domain, const std::string& host, void* iaddr, size_t size)
{
#if defined WIN32
    in_addr* saddr = reinterpret_cast<in_addr*>(iaddr);
    assert(saddr);

    // try IP address
    saddr->s_addr = inet_addr(host.c_str());
    if(saddr->s_addr == INADDR_NONE) {
        // failed, try hostname
        hostent* haddr = gethostbyname(host.c_str());
        if(!haddr) return false;

        // copy the in_addr
        std::memcpy(iaddr, haddr->h_addr_list[0], size);
    }
    return true;
#else
    // try IP address
    int rval = inet_pton(domain, host.c_str(), iaddr);
    if(rval < 0) return false;
    else if(!rval) {
        // failed, try hostname
        hostent* haddr = gethostbyname2(host.c_str(), domain);
        if(!haddr) return false;

        // copy the in_addr
        std::memcpy(iaddr, haddr->h_addr_list[0], size);
    }
    return true;
#endif
}


/*
 *  EnSocket methods
 *
 */


EnSocket::EnSocket()
    : m_sockfd(INVALID_SOCKET), m_domain(0)
{
}


EnSocket::EnSocket(SOCKET sockfd)
    : m_sockfd(sockfd), m_domain(0)
{
}


bool EnSocket::create(int domain, int type, int protocol)
{
    if(valid()) {
        shutdown();
        close();
    }
    m_domain = domain;

    m_sockfd = ::socket(m_domain, type, protocol);
    return valid();
}


bool EnSocket::shutdown(int how)
{
    if(!valid())
        return true;

    return ::shutdown(m_sockfd, how) != SOCKET_ERROR;
}


bool EnSocket::close()
{
    if(!valid())
        return true;

    bool retval = ::closesocket(m_sockfd) != SOCKET_ERROR;
    m_sockfd = INVALID_SOCKET;
    return retval;
}


bool EnSocket::send(const EnPacket& packet, int flags)
{
    return send(reinterpret_cast<const char*>(packet.sendable_buffer()), packet.length(), flags);
}


bool EnSocket::send(const char* const buffer, size_t len, int flags)
{
    if(!valid())
        return false;

    size_t sent(0);
    int rval(0);
    while(sent < len) {
        rval = ::send(m_sockfd, buffer + sent, len - sent, flags);
        if(rval == SOCKET_ERROR) return false;

        sent += rval;
    }
    return true;
}


bool EnSocket::sendto(const EnPacket& packet, int flags)
{
    return sendto(reinterpret_cast<const char*>(packet.sendable_buffer()), packet.length(), flags);
}


bool EnSocket::sendto(const char* buffer, size_t len, int flags)
{
    if(!valid())
        return false;

    size_t sent(0);
    int rval(0);
    while(sent < len) {
        rval = ::sendto(m_sockfd, buffer + sent, len - sent, flags, reinterpret_cast<sockaddr*>(&m_addr), sizeof(m_addr));
        if(rval == SOCKET_ERROR) return false;

        sent += rval;
    }
    return true;
}


int EnSocket::recv(EnPacket& packet, int flags)
{
    if(!valid())
        return false;

    char buffer[EnPacket::MaxPacket] = { 0 };

    int rval(0);
    do {
        rval = ::recv(m_sockfd, buffer, EnPacket::MaxPacket, flags);
    } while(rval == SOCKET_ERROR && last_socket_error() == SOCKET_WOULDBLOCK);
    if(rval <= 0) return rval;

    packet.received_buffer(reinterpret_cast<byte*>(buffer), rval);
    return rval;
}


int EnSocket::recv(char* buffer, size_t len, int flags)
{
    assert(buffer);

    if(!valid())
        return false;

    ZeroMemory(buffer, len);

    int rval(0);
    do {
        rval = ::recv(m_sockfd, buffer, len, flags);
    } while(rval == SOCKET_ERROR && last_socket_error() == SOCKET_WOULDBLOCK);
    if(rval <= 0) return rval;

    return rval;
}


int EnSocket::recvfrom(EnPacket& packet, int flags)
{
    if(!valid())
        return false;

    char buffer[EnPacket::MaxPacket] = { 0 };
    socklen_t len = sizeof(m_addr);

    int rval(0);
    do {
        rval = ::recvfrom(m_sockfd, buffer, EnPacket::MaxPacket, flags, reinterpret_cast<sockaddr*>(&m_addr), &len);
    } while(rval == SOCKET_ERROR && last_socket_error() == SOCKET_WOULDBLOCK);
    if(rval <= 0) return rval;

    packet.received_buffer(reinterpret_cast<byte*>(buffer), rval);
    return rval;
}


int EnSocket::recvfrom(char* buffer, size_t len, int flags)
{
    assert(buffer);

    if(!valid())
        return false;

    ZeroMemory(buffer, len);
    socklen_t alen = sizeof(m_addr);

    int rval(0);
    do {
        rval = ::recvfrom(m_sockfd, buffer, EnPacket::MaxPacket, flags, reinterpret_cast<sockaddr*>(&m_addr), &alen);
    } while(rval == SOCKET_ERROR && last_socket_error() == SOCKET_WOULDBLOCK);
    if(rval <= 0) return rval;

    return rval;
}


#if defined WIN32
bool EnSocket::setsockopt(int optname, const char* optval, socklen_t optlen, int level)
#else
bool EnSocket::setsockopt(int optname, const void* optval, socklen_t optlen, int level)
#endif
{
    if(!valid())
        return false;

    return ::setsockopt(m_sockfd, level, optname, optval, optlen) != SOCKET_ERROR;
}


#if defined WIN32
bool EnSocket::getsockopt(int optname, char* optval, socklen_t* optlen, int level)
#else
bool EnSocket::getsockopt(int optname, void* optval, socklen_t* optlen, int level)
#endif
{
    if(!valid())
        return false;

    return ::getsockopt(m_sockfd, level, optname, optval, optlen) != SOCKET_ERROR;
}


bool EnSocket::set_asynchronous()
{
    if(!valid())
        return false;

#if defined WIN32
    u_long mode = 0x01;
    return ioctlsocket(m_sockfd, FIONBIO, &mode) != SOCKET_ERROR;
#else
    int flags = fcntl(m_sockfd, F_GETFL, 0);
    return fcntl(m_sockfd, F_SETFL, O_NONBLOCK | flags) >= 0;
#endif
}


bool EnSocket::get_asynchronous()
{
    if(!valid())
        return false;

#if defined WIN32
/* TODO: write this */
    return false;
#else
    int flags = fcntl(m_sockfd, F_GETFL, 0);
    return flags & O_NONBLOCK;
#endif
}


bool EnSocket::set_synchronous()
{
    if(!valid())
        return false;

#if defined WIN32
    bool retval = WSAAsyncSelect(m_sockfd, NULL, 0, 0) != SOCKET_ERROR;
    u_long mode = 0x00;
    retval = (ioctlsocket(m_sockfd, FIONBIO, &mode) != SOCKET_ERROR) && retval;
    return retval;
#else
    int flags = fcntl(m_sockfd, F_GETFL, 0);
    return fcntl(m_sockfd, F_SETFL, ~O_NONBLOCK & flags) >= 0;
#endif
}


bool EnSocket::get_synchronous()
{
    if(!valid())
        return false;

    return !get_asynchronous();
}


#if defined WIN32
bool EnSocket::async_select(HWND hWnd, UINT uMsg, long lEvent)
{
    return WSAAsyncSelect(m_sockfd, hWnd, uMsg, lEvent) != SOCKET_ERROR;
}


bool EnSocket::event_select(WSAEVENT hEventObject, long lNetworkEvents)
{
    return WSAEventSelect(m_sockfd, hEventObject, lNetworkEvents) != SOCKET_ERROR;
}
#endif


/*
 *  EnServerSocket class functions
 *
 */


bool EnServerSocket::create_server_socket(EnServerSocket& socket, int domain, int type, unsigned short port)
{
    if(!socket.create(domain, type))
        return false;

#if defined WIN32
    char ival = 0x01;
#else
    int ival = 0x01;
#endif
    if(!socket.setsockopt(SO_REUSEADDR, &ival, sizeof(ival)))
        return false;

    if(!socket.bind(port))
        return false;

    if(!socket.listen())
        return false;

    return true;
}


/*
 *  EnServerSocket methods
 *
 */


EnServerSocket::EnServerSocket()
    : EnSocket()
{
}


EnServerSocket::EnServerSocket(SOCKET sockfd)
    : EnSocket(sockfd)
{
}


void EnServerSocket::create_addr(unsigned short port)
{
    ZeroMemory(&m_addr, sizeof(m_addr));

/* TODO: need an ipv6 version */

    m_addr.sin_family = m_domain;
    m_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    m_addr.sin_port = htons(port);
}


bool EnServerSocket::create_addr(const std::string& address, unsigned short port)
{
    ZeroMemory(&m_addr, sizeof(m_addr));

/* TODO: need an ipv6 version */

    if(!host_to_inaddr(m_domain, address, &m_addr.sin_addr, sizeof(m_addr.sin_addr)))
        return false;

    m_addr.sin_family = m_domain;
    m_addr.sin_port = htons(port);

    return true;
}


bool EnServerSocket::bind(unsigned short port)
{
    if(!valid())
        return false;

    create_addr(port);
    return ::bind(m_sockfd, reinterpret_cast<sockaddr*>(&m_addr), sizeof(m_addr)) != SOCKET_ERROR;
}


bool EnServerSocket::bind(const std::string& address, unsigned short port)
{
    if(!valid())
        return false;

    if(!create_addr(address, port))
        return false;

    return ::bind(m_sockfd, reinterpret_cast<sockaddr*>(&m_addr), sizeof(m_addr)) != SOCKET_ERROR;
}


bool EnServerSocket::listen(int backlog)
{
    if(!valid())
        return false;

    return ::listen(m_sockfd, backlog) != SOCKET_ERROR;
}


EnClientSocket EnServerSocket::accept()
{
    if(!valid())
        return EnClientSocket();

    sockaddr_in addr;
    socklen_t len = sizeof(addr);

    return EnClientSocket(::accept(m_sockfd, reinterpret_cast<sockaddr*>(&addr), &len));
}


/*
 *  EnClientSocket class functions
 *
 */


bool EnClientSocket::create_client_socket(EnClientSocket& socket, int domain, int type, const std::string& host, unsigned short port)
{
    if(!socket.create(domain, type))
        return false;

    if(!socket.connect(host, port))
        return false;

    return true;
}


/*
 *  EnClientSocket methods
 *
 */


EnClientSocket::EnClientSocket()
    : EnSocket()
{
}


EnClientSocket::EnClientSocket(SOCKET sockfd)
    : EnSocket(sockfd)
{
}


bool EnClientSocket::create_addr(const std::string& host, unsigned short port)
{
    ZeroMemory(&m_addr, sizeof(m_addr));

    if(!host_to_inaddr(m_domain, host, &m_addr.sin_addr, sizeof(m_addr.sin_addr)))
        return false;

    m_addr.sin_family = m_domain;
    m_addr.sin_port = htons(port);

    return true;
}


bool EnClientSocket::connect(const std::string& host, unsigned short port)
{
    if(!valid())
        return false;

    if(!create_addr(host, port))
        return false;

    return ::connect(m_sockfd, reinterpret_cast<sockaddr*>(&m_addr), sizeof(m_addr)) != SOCKET_ERROR;
}
