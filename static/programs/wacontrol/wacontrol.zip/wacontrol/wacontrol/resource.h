//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by wacontrol.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDS_INITWS2_32                  129
#define IDS_ERR_WINSOCK                 129
#define IDS_ERR_CREATE_WINDOW           130
#define IDS_ERR_LOG_REDIRECT            131
#define IDS_ERR_LOAD_CONFIG             132
#define IDS_ERR_SAVE_CONFIG             133
#define IDS_ERR_CONNECT                 134
#define IDS_ERR_SELECT                  135
#define IDS_ERR_RECVPACKET              136
#define IDS_ERR_PACKET                  137
#define IDS_ERR_SENDPACKET              138
#define IDS_ERR_PORTRANGE               139
#define IDS_ERR_SERVER_DISCONNECTED     140
#define IDR_TRAY_MENU                   202
#define IDD_CONNECT_DIALOG              203
#define IDD_PLAYLIST_DIALOG             206
#define IDC_DEFAULT                     1001
#define IDC_SERVER_EDIT                 1002
#define IDC_PORT_EDIT                   1003
#define IDC_FILENAME_EDIT               1004
#define ID_WINAMP_STOP                  32775
#define ID_WINAMP_PLAY                  32776
#define ID_FILE_CONNECT                 32779
#define ID_FILE_DISCONNECT              32780
#define ID_FILE_RESTORE                 32787
#define ID_Menu                         32788
#define ID_WINAMP_EXECUTE               32789
#define ID_WINAMP_CLOSE                 32790
#define ID_WINAMP_RESET                 32791
#define ID_WINAMP_PAUSE                 32798
#define ID_WINAMP_PREVIOUSSONG          32799
#define ID_WINAMP_NEXTSONG              32800
#define ID_Menu32805                    32805
#define ID_WINAMP_LOADPLAYLIST          32806
#define ID_Menu32810                    32810
#define ID_WINAMP_PLAYCD                32811
#define ID_WINAMP_FFW5                  32816
#define ID_WINAMP_REWIND5               32817
#define ID_WINAMP_VOLUMEUP              32820
#define ID_WINAMP_VOLUMEDOWN            32821

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        207
#define _APS_NEXT_COMMAND_VALUE         32828
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
