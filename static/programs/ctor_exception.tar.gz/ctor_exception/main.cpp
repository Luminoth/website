/*
==========

sample program to demonstrate proper method of throwing
    exception from a ctor

Author: Shane Lillie with help from Stuka and furrycat at http://www.linuxnewbie.org/

==========
*/

#include <stdexcept>
#include <string>
using namespace std;


class BigPoo
{
public:
    class BigPooException : public runtime_error
    {
    public:
        BigPooException(const string& what, char* poovar) throw() : std::runtime_error(what) { _poovar = poovar; if(_poovar) delete[] _poovar; }
        virtual ~BigPooException() throw() {}
        virtual const char* what() const throw() { return _what.c_str(); }

    private:
        string _what;
        char* _poovar;
    };

public:
    BigPoo() throw(BigPooException) : one(0), two(1), three(2), four(3), testPtr(NULL)
    {
        testPtr = new char[1024];
        throw BigPooException("poo", testPtr);
    }

    virtual ~BigPoo() throw()
    {
        delete[] testPtr;
    }

private:
    int one, two, three, four;
    char* testPtr;
};


int main(int argc, char* argv[])
{
    BigPoo* poo = NULL;
    while(true) {
        try {
            poo = new BigPoo();
        } catch(BigPoo::BigPooException e) {
            continue;
        }
    }
}
