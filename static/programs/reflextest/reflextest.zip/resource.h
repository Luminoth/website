//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ReflexTest.rc
//
#define IDD_REFTEST                     101
#define IDR_REFTEST                     102
#define ID_START                        1000
#define ID_STOP                         1001
#define IDC_SCORE                       1002
#define IDC_INSULT                      1004
#define ID_EXIT                         40001
#define ID_ABOUT                        40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
