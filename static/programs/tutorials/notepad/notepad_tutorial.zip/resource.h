//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by enpad.rc
//
#define IDR_MAIN_MENU                   102
#define IDD_ABOUT                       103
#define ID_FILE_EXIT                    40001
#define ID_EXIT                         40001
#define ID_HELP_ABOUT                   40002
#define ID_ABOUT                        40002
#define ID_SAVE_AS                      40003
#define ID_OPEN                         40004
#define ID_NEW                          40005
#define ID_SAVE                         40006
#define ID_UNDO                         40007
#define ID_CUT                          40008
#define ID_COPY                         40009
#define ID_PASTE                        40010
#define ID_DELETE                       40011
#define ID_SET_FONT                     40014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
