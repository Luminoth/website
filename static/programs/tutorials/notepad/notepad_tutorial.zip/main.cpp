#include <stdio.h>

#if !defined WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <commdlg.h>
#include "resource.h"


/*
 *  constants
 *
 */

const int  WINDOW_WIDTH    = 500;
const int  WINDOW_HEIGHT   = 400;
const char PROGRAM_NAME[]  = "EnPad";
const int  MAX_TEXT        = 2048;
const int  MAX_FILE        = 256;
const char FILTER[]        = "Text Documents\0*.enp;*.txt\0All Files (*.*)\0*.*";
const char DEF_EXTENSION[] = "enp";


/*
 *  prototypes
 *
 */

// window procedures
LRESULT CALLBACK WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AboutDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

// message handler functions
int new_file(HWND main_window, HWND edit_window, bool saved);
int open_file(HWND main_window, HWND edit_window);
int save(HWND main_window, HWND edit_window);
int save_as(HWND main_window, HWND edit_window);

// sets the font of the edit box
int set_font(HWND edit_window);
int set_font(HWND main_window, HWND edit_window);

// open/save text from/to file
int open_text(char* file, char* text, unsigned int len);
int save_text(char* file, char* text, unsigned int len);


/*
 *  globals
 *
 */

char g_long_filename[MAX_FILE*2];
char g_short_filename[MAX_FILE];
char g_title[MAX_FILE*2];


int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nShowCmd)
{
    memset(g_long_filename, 0, sizeof(g_long_filename));
    memset(g_short_filename, 0, sizeof(g_short_filename));
    strncpy(g_short_filename, "Untitled", sizeof(g_short_filename));

    memset(g_title, 0, sizeof(g_title));
    _snprintf(g_title, sizeof(g_title), "%s - %s", g_short_filename, PROGRAM_NAME);

    HWND       window_handle = NULL;
    MSG        message;
    WNDCLASSEX window_class;
    memset(&window_class, 0, sizeof(WNDCLASSEX));

    window_class.cbSize        = sizeof(WNDCLASSEX);
    window_class.style         = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
    window_class.lpfnWndProc   = WindowProc;
    window_class.cbClsExtra    = 0;
    window_class.cbWndExtra    = 0;
    window_class.hInstance     = hInstance;
    window_class.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    window_class.hCursor       = LoadCursor(NULL, IDC_ARROW);
    window_class.hbrBackground = (HBRUSH)COLOR_APPWORKSPACE;
    window_class.lpszMenuName  = (char*)IDR_MAIN_MENU;
    window_class.lpszClassName = PROGRAM_NAME;
    window_class.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if(0 == RegisterClassEx(&window_class)) {
        MessageBox(NULL, "Could not register main window class!", PROGRAM_NAME, MB_OK | MB_ICONERROR);
        return 0;
    }

    window_handle = CreateWindowEx(
        WS_EX_CONTROLPARENT,
        PROGRAM_NAME,
        g_title,
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT,
        WINDOW_WIDTH, WINDOW_HEIGHT,
        NULL,
        NULL,
        hInstance,
        NULL);
    if(NULL == window_handle) {
        MessageBox(NULL, "Could not create window!", PROGRAM_NAME, MB_OK | MB_ICONERROR);
        return 0;
    }

    ShowWindow(window_handle, nShowCmd);
    SetForegroundWindow(window_handle);

    while(GetMessage(&message, NULL, 0, 0)) {
        TranslateMessage(&message);
        DispatchMessage(&message);
    }

    return message.wParam;
}


LRESULT CALLBACK WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    static HWND edit_handle = NULL;
    static bool saved       = true;
    int r=0;

    switch(uMsg)
    {
    case WM_CREATE:
        edit_handle = CreateWindowEx(
            WS_EX_CLIENTEDGE,
            "EDIT",
            NULL,
            WS_CHILD | WS_VSCROLL | WS_HSCROLL | ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_LEFT | ES_MULTILINE | ES_WANTRETURN,
            0, 0,
            WINDOW_WIDTH, WINDOW_HEIGHT,
            hWnd,
            NULL,
            (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE),
            NULL);
        if(NULL == edit_handle)
            MessageBox(NULL, "Could not create edit control!", PROGRAM_NAME, MB_OK | MB_ICONERROR);

        if(set_font(edit_handle) < 0)
            MessageBox(NULL, "Could not set default edit font!", PROGRAM_NAME, MB_OK | MB_ICONERROR);

        ShowWindow(edit_handle, SW_SHOW);
        SetFocus(edit_handle);
        break;
    case WM_COMMAND:
        // look at the low word
        switch(LOWORD(wParam))
        {
        case ID_NEW:
            if(0 == new_file(hWnd, edit_handle, saved))  // file was saved (only thing we care about)
                saved = true;
            break;
        case ID_OPEN:
            r = open_file(hWnd, edit_handle);
            if(0 == r)  // file was opened
                saved = true;
            else if(r > 0)  // user changed mind
                break;
            else  // failed to open file
                MessageBox(hWnd, "There was an error opening the file!", PROGRAM_NAME, MB_OK | MB_ICONERROR);
            break;
        case ID_SAVE:
            r = save(hWnd, edit_handle);
            if(0 == r)  // file was saved
                saved = true;
            else if(r > 0)  // user changed their mind
                break;
            else  // failed to save file
                MessageBox(hWnd, "There was an error saving the file!", PROGRAM_NAME, MB_OK | MB_ICONERROR);
            break;
        case ID_SAVE_AS:
            r = save_as(hWnd, edit_handle);
            if(0 == r)  // file was saved
                saved = true;
            else if(r > 0)  // user changed their mind
                break;
            else  // failed to save file
                MessageBox(hWnd, "There was an error saving the file!", PROGRAM_NAME, MB_OK | MB_ICONERROR);
            break;        
        case ID_EXIT:
            if(0 == new_file(hWnd, edit_handle, saved))  // file was saved (only thing we care about)
                saved = true;
            PostQuitMessage(0);
            break;
        case ID_UNDO:
            if(SendMessage(edit_handle, EM_CANUNDO, NULL, NULL)) 
                SendMessage(edit_handle, WM_UNDO, NULL, NULL); 
            break;
        case ID_CUT:
            SendMessage(edit_handle, WM_CUT, NULL, NULL); 
            break;
        case ID_COPY:
            SendMessage(edit_handle, WM_COPY, NULL, NULL); 
            break;
        case ID_PASTE:
            SendMessage(edit_handle, WM_PASTE, NULL, NULL); 
            break;
        case ID_DELETE:
            SendMessage(edit_handle, WM_CLEAR, NULL, NULL); 
            break;
        case ID_SET_FONT:
            if(set_font(hWnd, edit_handle) < 0)
                MessageBox(hWnd, "There was an error setting the font!", PROGRAM_NAME, MB_OK | MB_ICONERROR);
            break;
        case ID_ABOUT:
            DialogBox((HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), (char*)IDD_ABOUT, hWnd, AboutDialogProc);
            break;
        }

        // look at the hi word value
        switch(HIWORD(wParam))
        {
        case EN_UPDATE:
            if(lParam == (LPARAM)edit_handle)
                saved = false;
            break;
        }
        break;
    case WM_SETFOCUS: 
        SetFocus(edit_handle);
        break;
    case WM_ACTIVATE:
        if(WA_INACTIVE != wParam)
            InvalidateRect(hWnd, NULL, false);
        break;
    case WM_SIZE:
        if(0 == MoveWindow(edit_handle, 0, 0, LOWORD(lParam), HIWORD(lParam), false))
            MessageBox(hWnd, "An error occured resizing the edit control!", PROGRAM_NAME, MB_OK | MB_ICONERROR);
        break;
    case WM_CLOSE:
    case WM_DESTROY:
        if(0 == new_file(hWnd, edit_handle, saved))  // file was saved (only thing we care about)
                saved = true;
        PostQuitMessage(0);
        break;
    }

    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


BOOL CALLBACK AboutDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch(uMsg)
    {
    case WM_COMMAND:
        switch(LOWORD(wParam))
        {
        case IDOK:
            EndDialog(hwndDlg, 0);
            break;
        }
        return TRUE;
    case WM_CLOSE:
    case WM_DESTROY:
        EndDialog(hwndDlg, 0);
        return TRUE;
    }

    return FALSE;
}


int new_file(HWND main_window, HWND edit_window, bool saved)
{
    int r =0;

    if(!saved) {
        r = MessageBox(main_window, "The text in the Untitled file has changed.\r\n\r\nDo you want to save the changes?", PROGRAM_NAME, MB_YESNOCANCEL | MB_ICONEXCLAMATION);
        if(IDCANCEL == r)
            return 1;
        else if(IDYES == r)
            save(main_window, edit_window);
    }

    // make it all new and pretty
    memset(g_long_filename, 0, sizeof(g_long_filename));
    memset(g_short_filename, 0, sizeof(g_short_filename));
    strncpy(g_short_filename, "Untitled", sizeof(g_short_filename));
    memset(g_title, 0, sizeof(g_title));
    _snprintf(g_title, sizeof(g_title), "%s - %s", g_short_filename, PROGRAM_NAME);
    SendMessage(edit_window, WM_SETTEXT, NULL, (LPARAM)"");
    SendMessage(main_window, WM_SETTEXT, NULL, (LPARAM)g_title);

    return 0;
}


int open_file(HWND main_window, HWND edit_window)
{
    char t_text[MAX_TEXT];
    OPENFILENAME t_open_file;

    memset(&t_text, 0, sizeof(t_text));
    memset(&t_open_file, 0, sizeof(OPENFILENAME));
    t_open_file.lStructSize    = sizeof(OPENFILENAME);
    t_open_file.hwndOwner      = main_window;
    t_open_file.lpstrFilter    = FILTER;
    t_open_file.lpstrFile      = g_long_filename;
    t_open_file.nMaxFile       = sizeof(g_long_filename);
    t_open_file.lpstrFileTitle = g_short_filename;
    t_open_file.nMaxFileTitle  = sizeof(g_short_filename);
    t_open_file.Flags          = OFN_CREATEPROMPT | OFN_NOREADONLYRETURN | OFN_PATHMUSTEXIST;
    t_open_file.lpstrDefExt    = DEF_EXTENSION;
    if(0 == GetOpenFileName(&t_open_file)) {
        if(0 != CommDlgExtendedError())
            return -1;
        else
            return 1;
    }

    memset(t_text, 0, sizeof(t_text));
    if(open_text(g_long_filename, t_text, sizeof(t_text)) < 0)
        return -2;
    SendMessage(edit_window, WM_SETTEXT, NULL, (LPARAM)t_text);
    
    memset(g_title, 0, sizeof(g_title));
    _snprintf(g_title, sizeof(g_title), "%s - %s", g_short_filename, PROGRAM_NAME);
    SendMessage(main_window, WM_SETTEXT, NULL, (LPARAM)g_title);

    return 0;
}


int save(HWND main_window, HWND edit_window)
{
    char t_text[MAX_TEXT];
    memset(&t_text, 0, sizeof(t_text));

    if(0 == strcmp(g_long_filename, "")) {
        // let the save_as procedure deal with it
        return save_as(main_window, edit_window);
    } else {
        // file was saved once already, so just reuse it
        memset(t_text, 0, sizeof(t_text));
        GetWindowText(edit_window, t_text, sizeof(t_text));
    
        if(save_text(g_long_filename, t_text, sizeof(t_text)) < 0)
            return -1;
    
        memset(g_title, 0, sizeof(g_title));
        _snprintf(g_title, sizeof(g_title), "%s - %s", g_short_filename, PROGRAM_NAME);
        SendMessage(main_window, WM_SETTEXT, NULL, (LPARAM)g_title);
    }

    return 0;
}


int save_as(HWND main_window, HWND edit_window)
{
    char t_text[MAX_TEXT];
    OPENFILENAME t_save_file;

    memset(&t_text, 0, sizeof(t_text));
    memset(&t_save_file, 0, sizeof(OPENFILENAME));
    t_save_file.lStructSize    = sizeof(OPENFILENAME);
    t_save_file.hwndOwner      = main_window;
    t_save_file.lpstrFilter    = FILTER;
    t_save_file.lpstrFile      = g_long_filename;
    t_save_file.nMaxFile       = sizeof(g_long_filename);
    t_save_file.lpstrFileTitle = g_short_filename;
    t_save_file.nMaxFileTitle  = sizeof(g_short_filename);
    t_save_file.Flags          = OFN_CREATEPROMPT | OFN_NOREADONLYRETURN | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    t_save_file.lpstrDefExt    = DEF_EXTENSION;
    if(0 == GetSaveFileName(&t_save_file)) {
        if(0 != CommDlgExtendedError())
            return -1;
        else
            return 1;
    }

    memset(t_text, 0, sizeof(t_text));
    GetWindowText(edit_window, t_text, sizeof(t_text));
    
    if(save_text(g_long_filename, t_text, sizeof(t_text)) < 0)
        return -2;
    
    memset(g_title, 0, sizeof(g_title));
    _snprintf(g_title, sizeof(g_title), "%s - %s", g_short_filename, PROGRAM_NAME);
    SendMessage(main_window, WM_SETTEXT, NULL, (LPARAM)g_title);

    return 0;
}


int set_font(HWND edit_window)
{
    HFONT t_font = CreateFont(12, 0, 0, 0, FW_NORMAL, false, false, false, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, 12, "Fixedsys");
    if(NULL == t_font)
        return -1;
    SendMessage(edit_window, WM_SETFONT, (WPARAM)t_font, MAKELONG(true, 0));

    return 0;
}


int set_font(HWND main_window, HWND edit_window)
{
    CHOOSEFONT choose_font;
    LOGFONT    l_font;
    HFONT      t_font = NULL;

    memset(&choose_font, 0, sizeof(CHOOSEFONT));
    memset(&l_font, 0, sizeof(LOGFONT));
    choose_font.lStructSize = sizeof(CHOOSEFONT);
    choose_font.hwndOwner   = main_window;
    choose_font.lpLogFont   = &l_font;
    choose_font.Flags       = CF_SCREENFONTS | CF_FORCEFONTEXIST | CF_INITTOLOGFONTSTRUCT;
    if(0 == ChooseFont(&choose_font)) {
        if(0 != CommDlgExtendedError())
            return -1;
        else
            return 1;
    }
    t_font = CreateFontIndirect(&l_font);
    if(NULL == t_font)
        return -2;
    SendMessage(edit_window, WM_SETFONT, (WPARAM)t_font, MAKELONG(true, 0));

    return 0;
}


int open_text(char* file, char* text, unsigned int len)
{
    FILE* f = NULL;

    memset(text, 0, len);
    f = fopen(file, "r");
    if(NULL == f)
        return -1;

    if(fread(text, sizeof(char), len, f) < len) {
        if(!feof(f)) {
            return -2;
            fclose(f);
        }
    }
    fclose(f);

    return 0;
}


int save_text(char* file, char* text, unsigned int len)
{
    FILE* f = NULL;
    f = fopen(file, "w");
    if(NULL == f)
        return -1;

    if(fwrite(text, sizeof(char), len, f) < len) {
        fclose(f);
        return -2;
    }
    fclose(f);

    return 0;
}