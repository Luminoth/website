#if !defined MODULE_H
#define MODULE_H


#include <string>

#include <dlfcn.h>


class Module
{
public:
    /*
     *  public constructors/destructors
     *
     */

    // creates a module
    Module();

    // creates a module with specified filename but doesn't open it
    explicit Module(const string& filename);

    // destroys the module
    ~Module() throw();

public:
    /*
     *  public methods
     *
     */

    // opens the module
    const bool open(const int flags=RTLD_LAZY);

    // opens the specified module
    const bool open(const std::string& filename, const int flags=RTLD_LAZY);

    // closes the module
    const bool close() throw();

    // gets a symbol from the module
    void* getSymbol(const std::string& symbol);

public:
    /*
     *  public inline methods
     *
     */

    // checks if the module is open
    inline const bool isOpen() const
    {
        return m_handle != NULL;
    }

    // returns the last error message
    inline const std::string& getLastError() const
    {
        return m_lastError;
    }

private:
    /*
     *  private methods
     *
     */

    void saveLastError();

private:
    /*
     *  private members
     *
     */

    // the module filename
    std::string m_filename;

    // the module handle
    void* m_handle;

    // the last error message
    std::string m_lastError;
};


#endif
