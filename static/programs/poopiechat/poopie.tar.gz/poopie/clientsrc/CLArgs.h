#if !defined CLARGS_H
#define CLARGS_H


#include <stdexcept>
#include <map>
#include <string>


class CLArgs
{
public:
    /*
     *  public exceptions
     *
     */

    class NoSuchVarException : public exception
    {
    public:
        NoSuchVarException(const std::string& what) : _what(what) {}
        virtual const char* what() const { return _what.c_str(); }
    private:
        std::string _what;
    };

public:
    /*
     *  public constructors/destructors
     *
     */

    CLArgs() {}

public:
    /*
     *  public methods
     *
     */

    // registers a variable based on its name and its value
    void registerVar(const std::string& name, const std::string& value);

    // checks to see if a variable exists
    const bool peakVar(const std::string& name);

    // finds the variable with name and returns its value
    const std::string& findVar(const std::string& name) throw(std::runtime_error);

    // unregisters the variable with name
    void unregisterVar(const std::string& name);

private:
    /*
     *  private members
     *
     */

    // the vector of variable names and their values
    std::map<std::string, std::string> m_argMap;
};


#endif
