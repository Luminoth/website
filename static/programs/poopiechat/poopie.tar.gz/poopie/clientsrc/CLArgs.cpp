#include "CLArgs.h"


void CLArgs::registerVar(const std::string& name, const std::string& value)
{
    m_argMap[name] = value;
}


const bool CLArgs::peakVar(const std::string& name)
{
    std::map<std::string, std::string>::iterator iterator;
    iterator = m_argMap.find(name);
    if(iterator != m_argMap.end())
        return true;
    return false;
}


const string& CLArgs::findVar(const std::string& name) throw(std::runtime_error)
{
    std::map<std::string, std::string>::iterator iterator;
    iterator = m_argMap.find(name);
    if(iterator != m_argMap.end())
        return iterator->second;
    throw std::runtime_error("Variable does not exist");
}


void CLArgs::unregisterVar(const std::string& name)
{
    m_argMap.erase(name);
}
