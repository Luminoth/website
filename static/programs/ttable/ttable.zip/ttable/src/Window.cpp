/**
\file Window.cpp
\brief Window class definition.
\author Shane Lillie

\verbatim
Copyright 2003 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
\endverbatim
*/

#pragma warning(disable : 4312)
#pragma warning(disable : 4311)

#include <string>

#include "../include/Window.h"
#include "../include/error.h"


/*
 *  Window class functions
 *
 */


void Window::RegisterClass(HINSTANCE hInstance, DWORD dwStyle, const std::string& name)
    throw(WindowException)
{
    WNDCLASSEX wndcls;
    wndcls.cbSize        = sizeof(WNDCLASSEX);
    wndcls.style         = dwStyle;
    wndcls.lpfnWndProc   = StaticWndProc;
    wndcls.cbClsExtra    = 0;
    wndcls.cbWndExtra    = 0;
    wndcls.hInstance     = hInstance;
    wndcls.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wndcls.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wndcls.hbrBackground = (HBRUSH)COLOR_APPWORKSPACE+1;
    wndcls.lpszMenuName  = NULL;
    wndcls.lpszClassName = name.c_str();
    wndcls.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if(!RegisterClassEx(&wndcls))
        throw WindowException("Could not register window class: " + last_error());
}


/**
@return A pointer to the Window class associated with the window handle.
*/
Window* const Window::getWindow(HWND hWnd)
{
    return reinterpret_cast<Window*>(GetWindowLong(hWnd, GWL_USERDATA));
}


/**
\brief The static window procedure.
@todo Round out the set of handled messages.
*/
LRESULT CALLBACK Window::StaticWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if(uMsg == WM_NCCREATE)
        SetWindowLong(hWnd, GWL_USERDATA, reinterpret_cast<LONG>(reinterpret_cast<LPCREATESTRUCT>(lParam)->lpCreateParams));

    Window* window = getWindow(hWnd);
    if(window) {
        if(!window->m_hWnd)
            window->m_hWnd = hWnd;

        switch(uMsg)
        {
        case WM_CREATE:
            if(!window->OnCreate(reinterpret_cast<LPCREATESTRUCT>(wParam)))
                return -1;
            break;
        case WM_SIZE:
            window->OnSize(static_cast<UINT>(wParam), LOWORD(lParam), HIWORD(lParam));
            break;
        case WM_CONTEXTMENU:
            window->OnContextMenu(reinterpret_cast<HWND>(wParam), GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
            break;
        case WM_CLOSE:
            window->OnClose();
            break;
        case WM_DESTROY:
            window->OnDestroy();
            break;
        case WM_COMMAND:
            if(!window->OnCommand(LOWORD(wParam), reinterpret_cast<HWND>(lParam), HIWORD(wParam)))
                return DefWindowProc(hWnd, uMsg, wParam, lParam);
            break;
        case WM_NOTIFY:
            if(!window->OnNotify(static_cast<int>(wParam), reinterpret_cast<LPNMHDR>(lParam)))
                return DefWindowProc(hWnd, uMsg, wParam, lParam);
            break;
        default:
            return DefWindowProc(hWnd, uMsg, wParam, lParam);
        }
    } else return DefWindowProc(hWnd, uMsg, wParam, lParam);
    return 0;
}


/*
 *  Window methods
 *
 */


Window::Window(HINSTANCE hInstance)
    : m_hInstance(hInstance), m_hWnd(NULL)
{
}


Window::~Window()
{
    if(IsWindow(m_hWnd))
        DestroyWindow();
}


bool Window::Create(DWORD dwExStyle, const std::string& class_name, const std::string& title, DWORD dwStyle)
{
    m_hWnd = CreateWindowEx(
            dwExStyle,
            class_name.c_str(),
            title.c_str(),
            dwStyle,
            CW_USEDEFAULT, CW_USEDEFAULT,
            CW_USEDEFAULT, CW_USEDEFAULT,
            NULL,
            NULL,
            instance(),
            this);

    return (m_hWnd != NULL);
}


BOOL Window::ShowWindow(int nCmdShow)
{
    return ::ShowWindow(m_hWnd, nCmdShow);
}


BOOL Window::UpdateWindow()
{
    return ::UpdateWindow(m_hWnd);
}


HWND Window::SetFocus()
{
    return ::SetFocus(m_hWnd);
}


void Window::SetGuiFont()
{
    SetWindowFont(m_hWnd, GetStockObject(DEFAULT_GUI_FONT), FALSE);
}


void Window::SetText(const std::string& text)
{
    ::SetWindowText(m_hWnd, text.c_str());
}


BOOL Window::MoveWindow(int x, int y, int width, int height, BOOL bRepaint)
{
    RECT rect;
    GetWindowRect(&rect);

    return ::MoveWindow(m_hWnd,
        (x == -1) ? rect.left : x,
        (y == -1) ? rect.top : y,
        (width == -1) ? rect.right : width,
        (height == -1) ? rect.bottom : height,
        bRepaint);
}


BOOL Window::GetClientRect(LPRECT rect)
{
    return ::GetClientRect(m_hWnd, rect);
}


BOOL Window::GetWindowRect(LPRECT rect)
{
    return ::GetWindowRect(m_hWnd, rect);
}


BOOL Window::DestroyWindow() throw()
{
    BOOL r = ::DestroyWindow(m_hWnd);
    m_hWnd = NULL;
    return r;
}


HMENU Window::GetMenu()
{
    return ::GetMenu(m_hWnd);
}


BOOL Window::SetMenu(HMENU hMenu)
{
    return ::SetMenu(m_hWnd, hMenu);
}


LRESULT Window::SendMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    return ::SendMessage(m_hWnd, uMsg, wParam, lParam);
}


int Window::MessageBox(const std::string& text, const std::string& caption, UINT uType)
{
    return ::MessageBox(m_hWnd, text.c_str(), caption.c_str(), uType);
}