/**
\file Window.h
\brief Window class declaration.
\author Shane Lillie

\verbatim
Copyright 2003 Energon Software

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
\endverbatim

\note All Windows headers are included by this, so just include it.
*/


#if !defined WINDOW_H
#define WINDOW_H


#pragma warning(disable : 4290)


#include <stdexcept>
#include <string>

#if !defined WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <commdlg.h>
#include <richedit.h>
#include <shellapi.h>

#include "controls.h"
#include "../rsc/resource.h"


/**
\brief Base window class.

Subclass this to get more specificly detailed windows.
*/
class Window
{
public:
    /// Generic window class exception.
    class WindowException : public std::exception
    {
    public:
        explicit WindowException(const std::string& what) : _what(what) {}
        virtual ~WindowException() throw() {}
        virtual const char* what() const throw() { return _what.c_str(); }
    private:
        std::string _what;
    };

public:
    /**
    \brief Registers a new window class.
    @param hInstance The program instance.
    @param style The class style.
    @param name The class name.
    @return The value returned by RegisterClassEx().
    @throw A WindowException containing the error that occurred.
    */
    static void RegisterClass(HINSTANCE hInstance, DWORD dwStyle, const std::string& name) throw(WindowException);

private:
	static Window* const getWindow(HWND hWnd);
    static LRESULT CALLBACK StaticWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

public:
    /// Constructs a new Window object (but not the actual window).
    explicit Window(HINSTANCE hInstance=NULL);

    /// Destroys the window if it's valid.
    virtual ~Window() throw();

public:
    /**
    \brief Creates the window itself with CreateWindowEx().
    @param ex_style The extended window style.
    @param class_name The window class name.
    @param title The window title.
    @param style The window style.
    @retval true The window was created successfully.
    @retval false The window creation failed. Use last_error() for details.
    */
    bool Create(DWORD dwExStyle, const std::string& class_name, const std::string& title, DWORD dwStyle);

    /// Shows the window.
    BOOL ShowWindow(int nCmdShow);

    /// Updates the window.
    BOOL UpdateWindow();

    /// Focuses the window.
    HWND SetFocus();

    /// Sets the window's font to the default GUI font.
    void SetGuiFont();

    /// Sets the window text.
    void SetText(const std::string& text);

    /// Repositions and sizes the window.
    BOOL MoveWindow(int x, int y, int width, int height, BOOL bRepaint);

    /// Puts the client rect in rect.
    BOOL GetClientRect(LPRECT rect);

    /// Puts the window rect in rect.
    BOOL GetWindowRect(LPRECT rect);

    /// Destroys the window.
    BOOL DestroyWindow() throw();

    /// Returns a handle to the window's menu if it has one.
    HMENU GetMenu();

    /// Sets the window's menu.
    BOOL SetMenu(HMENU hMenu);

    /// Sends a message to the window.
    LRESULT SendMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

    /// Displays a message box as a child of the window.
    int MessageBox(const std::string& text, const std::string& caption, UINT uType);

public:
    /// Returns the application instance.
    HINSTANCE instance() const
    {
        return m_hInstance;
    }

    /// Returns a handle to the window.
    HWND handle() const
    {
        return m_hWnd;
    }

    operator bool () const
    {
        return (m_hWnd != NULL);
    }

protected:
    /**
    \brief WM_CREATE handler.
    @param lpCreateStruct Pointer to a CREATESTRUCT structure that contains information about the window being created.
    @retval true Creation succeeded.
    @retval false Creation failed, window will be destroyed.
    */
    virtual bool OnCreate(LPCREATESTRUCT const lpCreateStruct) { return true; }

    /**
    \brief WM_SIZE handler.
    @param state Specifies the type of resizing requested.
    @param cx New width of the client area.
    @param cy New height of the client area.
    */
    virtual void OnSize(UINT state, int cx, int cy) {}

    /**
    \brief WM_CONTEXTMENU handler.
    @param hWndCtl Handle to the window in which the user right clicked the mouse.
        This can be a child window of the window receiving the message.
    @param x The horizontal position of the cursor, in screen coordinates, at the time of the mouse click.
    @param y The vertical position of the cursor, in screen coordinates, at the time of the mouse click.
    */
    virtual void OnContextMenu(HWND hWndCtl, int x, int y) {}

    /**
    \brief WM_COMMAND handler.
    @param id Identifier of the menu item, control, or accelerator.
    @param hWndCtl Handle to the control sending the message if the message is from a control.\n
        Otherwise, this parameter is NULL.
    @param codeNotify The notification code if the message is from a control.\n
        If the message is from an accelerator, this value is 1.\n
        If the message is from a menu, this value is zero.
    @retval true The message was handled.
    @retval false The message was not handled.
    */
    virtual bool OnCommand(int id, HWND hWndCtl, UINT codeNotify) { return false; }

    /**
    \brief WM_NOTIFY handler.
    @param idCtrl Identifier of the common control sending the message.\n
        This identifier is not guaranteed to be unique.\n
        An application should use the hwndFrom or idFrom member of the NMHDR structure to identify the control. 
    @param pnmh Pointer to an NMHDR structure that contains the notification code and additional information.\n
        For some notification messages, this parameter points to a larger structure that has the NMHDR structure as its first member. 
    @retval true The message was handled.
    @retval false The message was not handled.
    */
    virtual bool OnNotify(int idCtrl, LPNMHDR const pnmh) { return false; }

    /// WM_CLOSE handler.
    virtual void OnClose() {}

    /// WM_DESTROY handler.
    virtual void OnDestroy() {}

private:
    HINSTANCE m_hInstance;
    HWND m_hWnd;
};


#endif