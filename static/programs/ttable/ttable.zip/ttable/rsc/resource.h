//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ttable.rc
//
#define IDR_MAIN_MENU                   101
#define ID_FILE_EXIT                    102
#define ID_GENERATE_GENERATE            103
#define ID_GENERATE_AND                 104
#define ID_GENERATE_OR                  105
#define ID_GENERATE_XOR1                106
#define ID_GENERATE_XOR2                107
#define ID_GENERATE_NAND                108
#define ID_GENERATE_NOR                 109
#define ID_GENERATE_NOT                 110
#define ID_FILE_SAV                     111
#define ID_GENERATE_CLEAR               112
#define ID_MODE_FUNCTION                113
#define ID_MODE_MINTERM                 114
#define ID_MODE_MAXTERM                 115
#define ID_GENERATE_XOR                 116
#define ID_GENERATE_XNOR                119
#define ID_GENERATE_XNOR1               120
#define ID_GENERATE_XNOR2               121
#define ID_GENERATE_XNOR3               122

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        123
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
